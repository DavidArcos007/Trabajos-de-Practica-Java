/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Deber_004;

import Deber_003.*;

/**
 *
 * @author DELL 2019
 */
public abstract class Figura {

    abstract double calcArea();

    abstract double calcPerim();
}
